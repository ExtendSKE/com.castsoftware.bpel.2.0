First set the environment using the obsetenv.

Then build and deploy using obant from this directory. 

Oracle BPEL Process Manager 2.0 must be running.
